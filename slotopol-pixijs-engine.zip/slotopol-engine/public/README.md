# Public Assets

Place art assets here to replace the procedural symbol graphics.

## Recommended structure:
```
public/
├── symbols/
│   ├── bookofra/
│   │   ├── 1_explorer.png
│   │   ├── 2_mummy.png
│   │   ├── 3_statue.png
│   │   ├── ...
│   │   └── 10_book.png
│   └── {other_game}/
├── backgrounds/
│   └── bookofra_bg.jpg
└── audio/
    ├── spin.mp3
    ├── win_small.mp3
    ├── win_big.mp3
    └── freespin_trigger.mp3
```

## Symbol Sizes
- Recommended: 132×132 pixels (fits the 140px cell with 4px padding)
- Format: PNG with transparency
- Each symbol should have a consistent style per game
