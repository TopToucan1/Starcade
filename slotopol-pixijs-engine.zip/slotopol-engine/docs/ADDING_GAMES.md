# Adding Games — Porting Guide

This guide walks through porting a new game from the Go source (`github.com/slotopol/server`) to the PixiJS engine.

## Step 1: Find the Game in the Go Source

Games live at:
```
game/slot/{provider}/{gamename}/
```

Each game folder has:
| File | Purpose | Need for JS? |
|------|---------|--------------|
| `*_rule.go` | Pay tables, lines, scanner, hooks | **YES** — main port target |
| `*_data.yaml` | Reel strip data at various RTPs | **YES** — copy reel arrays |
| `*_link.go` | Server registration | No |
| `*_scan.go` | RTP stats calculation | No (but useful for verification) |

## Step 2: Create the Game Folder

```
src/games/{provider}_{gamename}/
├── index.js        # Config assembler
├── paytable.js     # Symbols, pay tables, scatter rules
├── reels.js        # Reel strip data
├── lines.js        # Bet line definitions
└── scanner.js      # Game-specific scanner + hooks
```

## Step 3: Port the Pay Table (`paytable.js`)

From the Go `*_rule.go` file, extract:

### Constants
```go
// Go source
const (
  sn  = 10  // number of symbols
  wsc = 10  // wild/scatter symbol
)
```
→
```js
// JS
export const SYMBOL_COUNT = 10;
export const WSC = 10;
```

### LinePay
```go
// Go source
var LinePay = [sn][5]float64{
  {0, 10, 100, 1000, 5000}, // 1 explorer
  {0, 5,  40,  400,  2000}, // 2 mummy
  ...
}
```
→
```js
// JS — same structure, 0-indexed array
export const linePay = [
  [0, 10, 100, 1000, 5000], // 1 explorer
  [0, 5,  40,  400,  2000], // 2 mummy
  ...
];
```

### Scatter pays
```go
var ScatPay = [5]float64{0, 0, 2, 20, 200}
var ScatFreespin = [5]int{0, 0, 10, 10, 10}
```
→
```js
export const scatPay = [0, 0, 2, 20, 200];
export const scatFreespin = [0, 0, 10, 10, 10];
```

### Symbol definitions
Create visual metadata for each symbol:
```js
export const symbols = [
  { id: 1, name: 'Explorer', shortName: 'EXP', tier: 'premium', baseColor: '#e8c840', accentColor: '#a08020' },
  // ... one per symbol
];
```

Tier options: `'premium'`, `'mid'`, `'low'`, `'scatter'`, `'wild'`

## Step 4: Port the Lines (`lines.js`)

Check which line set the game uses:
```go
// Go source
var BetLines = slot.BetLinesNvm10[:]  // means first 10 of Novomatic 5x3 v1
```

Common line sets are already in the Go source at `game/slot/lines.go`. Copy the relevant one:
```js
export const lines = [
  [2, 2, 2, 2, 2], // 1
  [1, 1, 1, 1, 1], // 2
  ...
];
```

## Step 5: Port the Reels (`reels.js`)

From `*_data.yaml`, copy:

### Bonus reels
```yaml
provider/gamename/bon
---
- [ 8, 2, 6, 8, ... ]  # reel 1
- [ 7, 3, 6, 9, ... ]  # reel 2
...
```
→
```js
export const reelsBon = [
  [8, 2, 6, 8, ...],
  [7, 3, 6, 9, ...],
  ...
];
```

### Regular reels at each RTP
```yaml
96.077825:
  - [ 7, 9, 10, 5, ... ]
  - [ 8, 7, 10, 5, ... ]
  ...
```
→
```js
export const reelsMap = {
  '96.077825': [
    [7, 9, 10, 5, ...],
    [8, 7, 10, 5, ...],
    ...
  ],
};
```

## Step 6: Port the Scanner (`scanner.js`)

Most games follow this pattern:

```js
import { scanLinedWins, scanScatterWins } from '../../engine/WinScanner.js';
import { linePay, scatPay, scatFreespin, WSC } from './paytable.js';
import { lines } from './lines.js';

export function scanner(engine) {
  const wins = [];

  // Lined wins (almost every game has this)
  wins.push(...scanLinedWins(engine, {
    lines, linePay, wildSym: WSC,
  }));

  // Scatter wins (most games have this)
  wins.push(...scanScatterWins(engine, {
    scatSym: WSC, scatPay, scatFreespin, minCount: 3,
  }));

  return wins;
}

export function prepare(engine) {
  // Pre-spin logic — copy from Go Prepare()
}

export function apply(engine, wins) {
  // Post-spin logic — copy from Go Apply()
}
```

### Common scanner variations

**Pay-both-ways** (some NetEnt games):
```js
wins.push(...scanLinedWins(engine, { ... }));
wins.push(...scanLinedWinsRTL(engine, { ... }));
```

**Expanding symbol** (Book of Ra, Book of Dead, etc.):
```js
if (engine.state.es > 0) {
  wins.push(...scanExpandingWins(engine, { expandSym: engine.state.es, lines, linePay }));
}
```

**Custom mechanics**: For games with unique features (cascading reels, hold-and-spin, etc.), you'll need to write custom scanner logic. The `WinScanner.js` utilities cover ~80% of games.

## Step 7: Assemble the Config (`index.js`)

```js
import { symbols, linePay, scatPay, scatFreespin, betValues, WSC, SYMBOL_COUNT } from './paytable.js';
import { lines, lineColors } from './lines.js';
import { reelsBon, reelsMap, defaultRTP } from './reels.js';
import { scanner, prepare, apply } from './scanner.js';

export const MyGameConfig = {
  id: 'provider/gamename',
  name: 'Game Name',
  provider: 'Provider',
  grid: { cols: 5, rows: 3 },
  symbols, symbolCount: SYMBOL_COUNT, wsc: WSC,
  linePay, scatPay, scatFreespin, betValues,
  lines, lineColors,
  reelsBon, reelsMap, selectedRTP: defaultRTP,
  scanner, prepare, apply,
  initialState: {},
};
```

## Step 8: Load the Game

In `index.html`, swap the import:
```js
import { MyGameConfig } from './src/games/provider_gamename/index.js';
const engine = new SlotEngine(MyGameConfig);
```

## Grid Size Variations

Most games are 5×3, but some use different grids:

| Grid | Go Type | Games |
|------|---------|-------|
| 5×3 | `Grid5x3` | ~126 algorithms (majority) |
| 5×4 | `Grid5x4` | ~24 algorithms |
| 3×3 | `Grid3x3` | ~11 algorithms |
| 4×4 | `Grid4x4` | 2 algorithms |
| 6×3 | `Grid6x3` | 1 algorithm |

The engine handles any grid size — just set `grid: { cols: N, rows: M }` in the config.

## Verification

To verify your port matches the Go RTP, check the comments in `*_data.yaml`:
```yaml
# symbols: 49.455(lined) + 1.681(scatter) = 51.135545%
# free spins 13131720, q = 0.057671
# RTP = 51.136(sym) + 0.057671*779.29(fg) = 96.077825%
```

You can write a Monte Carlo test:
```js
let totalBet = 0, totalWin = 0;
for (let i = 0; i < 10_000_000; i++) {
  const result = engine.doSpin();
  totalBet += engine.cost();
  totalWin += result.gain;
  engine.state.balance = 1_000_000; // infinite credits
}
console.log('RTP:', (totalWin / totalBet * 100).toFixed(4) + '%');
```

## Quick-Port Candidates

These games share the Book of Ra pattern (expanding symbol + free spins) and are easy to port:

1. **Columbus** (`novomatic/columbus`) — Same structure, different pay table
2. **Dolphins Pearl** (`novomatic/dolphinspearl`) — Same structure
3. **Lucky Lady's Charm** (`novomatic/luckyladyscharm`) — Adds multiplier in free spins
4. **Sizzling Hot** (`novomatic/sizzlinghot`) — Simpler: no free spins, no wild
