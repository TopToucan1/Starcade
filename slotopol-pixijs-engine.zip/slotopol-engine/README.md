# Slotopol PixiJS Engine

A universal HTML5 slot machine engine built with PixiJS, ported from the [slotopol/server](https://github.com/slotopol/server) Go backend. The math is a direct port from the original Go source — real reel strips, real pay tables, real RTP calculations.

## Architecture

```
slotopol-engine/
├── index.html                  # Entry point — loads everything
├── package.json                # Project config (for Replit/npm)
├── README.md                   # This file
│
├── src/
│   ├── engine/
│   │   ├── SlotEngine.js       # Universal game engine (state, spin cycle, balance)
│   │   └── WinScanner.js       # Reusable win-scanning utilities (lined, scatter, expanding)
│   │
│   ├── games/
│   │   └── bookofra/
│   │       ├── index.js         # Game config (ties everything together)
│   │       ├── paytable.js      # Pay tables, scatter pays, symbol defs
│   │       ├── reels.js         # Reel strip data at multiple RTP levels
│   │       ├── lines.js         # Bet line definitions
│   │       └── scanner.js       # Game-specific win scanner + prepare/apply hooks
│   │
│   ├── renderer/
│   │   ├── SlotRenderer.js     # Main PixiJS renderer (stage setup, resize, layers)
│   │   ├── ReelDisplay.js      # Reel grid rendering + spin animation
│   │   ├── SymbolFactory.js    # Procedural symbol texture generation
│   │   └── WinPresentation.js  # Win line drawing, highlights, big win display
│   │
│   └── ui/
│       └── UIController.js     # HTML UI binding (buttons, displays, events)
│
├── public/                     # Static assets (placeholder — add real art here)
│
└── docs/
    └── ADDING_GAMES.md         # Guide: how to port another game from Go source
```

## How to Run

### Replit
1. Import this project into Replit
2. It will auto-detect the HTML/JS project
3. Click Run — it serves `index.html` directly

### Local Development
```bash
npx serve .
# or
python3 -m http.server 8000
```
Open `http://localhost:8000` in your browser.

## How the Engine Works

### Spin Cycle
Every spin follows this pipeline (mirroring the Go server):

```
prepare() → deductCost() → spinReels() → scan() → apply() → creditWins()
```

1. **prepare()** — Game-specific pre-spin logic (e.g., clear expanding symbol if not in free spins)
2. **deductCost()** — Subtract bet × lines from balance (skipped in free spin mode)
3. **spinReels()** — Pick random position on each reel strip, fill the grid
4. **scan()** — Run the game's win scanner to detect all winning combinations
5. **apply()** — Game-specific post-spin logic (e.g., pick expanding symbol for free spins)
6. **creditWins()** — Add total winnings to balance

### Game Definition Format
Each game is a config object with:

| Field | Type | Description |
|-------|------|-------------|
| `id` | string | Provider/game identifier (e.g., `"novomatic/bookofra"`) |
| `grid` | `{cols, rows}` | Grid dimensions |
| `symbols` | array | Symbol definitions with id, name, tier, colors |
| `linePay` | 2D array | `linePay[symbolIdx][count-1]` → payout multiplier |
| `scatPay` | array | `scatPay[count-1]` → scatter payout multiplier |
| `scatFreespin` | array | `scatFreespin[count-1]` → free spins awarded |
| `wsc` | number | Wild/scatter symbol ID |
| `lines` | array of arrays | Bet line patterns (1-based row positions per column) |
| `betValues` | array | Available bet denominations |
| `reelsBon` | 2D array | Bonus/free spin reel strips |
| `reelsMap` | object | `{ "rtp_value": reelStrips }` for each RTP level |
| `selectedRTP` | string | Currently active RTP key |
| `scanner(engine)` | function | Returns array of win objects |
| `prepare(engine)` | function | Pre-spin hook |
| `apply(engine, wins)` | function | Post-spin hook |

### Win Object Format
```js
{
  pay: 50,        // Payment amount (bet × paytable value)
  mp: 1,          // Multiplier (for wilds, features)
  sym: 3,         // Winning symbol ID
  num: 4,         // Number of matching symbols
  li: 2,          // Line index (0 for scatters)
  xy: [[1,2],[2,2],[3,2],[4,2]],  // Hit positions [col, row] (1-based)
  fs: 0,          // Free spins awarded by this win
}
```

## Porting Games from Go Source

See `docs/ADDING_GAMES.md` for a detailed walkthrough.

**Quick summary:** Each game in the Go repo at `game/slot/{provider}/{game}/` has:
- `*_rule.go` — Pay tables, line defs, scanner logic, prepare/apply
- `*_data.yaml` — Reel strip data at multiple RTP levels
- `*_link.go` — Registration (ignore for JS port)
- `*_scan.go` — RTP calculation stats (ignore for JS port)

You only need `_rule.go` and `_data.yaml` to port a game.

## Go Source Reference

The original Go engine lives at: https://github.com/slotopol/server

Key source files for understanding the engine:
- `game/slot/slot.go` — Core types (WinItem, Wins, SlotGame interface, Slotx base struct)
- `game/slot/grid.go` — Grid types (Grid5x3, Grid5x4, etc.)
- `game/slot/lines.go` — All bet line definitions
- `game/slot/reels.go` — Reel strip types and scanning

## Current Status

- [x] Universal SlotEngine with full game state management
- [x] Reusable win scanning utilities (lined, scatter, expanding symbol)
- [x] Book of Ra — fully ported with real math from Go source
- [x] PixiJS renderer with procedural symbols
- [x] Reel spin animation with staggered stopping
- [x] Win line visualization + symbol highlighting
- [x] Free spins with auto-play
- [x] Expanding symbol mechanic
- [ ] Double-up / gamble feature
- [ ] Sound effects
- [ ] Real art assets (currently procedural)
- [ ] Additional games (340 available in Go source)
- [ ] Mobile touch controls
- [ ] Game selection menu
