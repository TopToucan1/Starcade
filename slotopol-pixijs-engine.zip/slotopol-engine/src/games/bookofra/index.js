/**
 * Book of Ra — Complete game configuration.
 *
 * This is the single import needed to register Book of Ra with the engine.
 * It assembles all game components into the standard game definition format.
 *
 * Usage:
 *   import { BookOfRaConfig } from './games/bookofra/index.js';
 *   const engine = new SlotEngine(BookOfRaConfig);
 */

import { symbols, linePay, scatPay, scatFreespin, betValues, WSC, SYMBOL_COUNT } from './paytable.js';
import { lines, lineColors } from './lines.js';
import { reelsBon, reelsMap, defaultRTP } from './reels.js';
import { scanner, prepare, apply } from './scanner.js';

export const BookOfRaConfig = {
  // ── Identity ──
  id: 'novomatic/bookofra',
  name: 'Book of Ra',
  provider: 'Novomatic',

  // ── Grid ──
  grid: { cols: 5, rows: 3 },

  // ── Symbols ──
  symbols,
  symbolCount: SYMBOL_COUNT,
  wsc: WSC,

  // ── Pay tables ──
  linePay,
  scatPay,
  scatFreespin,
  betValues,

  // ── Lines ──
  lines,
  lineColors,

  // ── Reels ──
  reelsBon,
  reelsMap,
  selectedRTP: defaultRTP,

  // ── Game logic hooks ──
  scanner,
  prepare,
  apply,

  // ── Initial game-specific state ──
  // es = expanding symbol (0 = none, set during free spins)
  initialState: {
    es: 0,
  },
};
