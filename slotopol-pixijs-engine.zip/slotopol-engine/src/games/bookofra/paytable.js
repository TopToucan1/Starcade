/**
 * Book of Ra — Pay tables & symbol definitions.
 *
 * Ported from: game/slot/novomatic/bookofra/bookofra_rule.go
 * Source constants: LinePay, ScatPay, ScatFreespin, sn, wsc
 */

/** Number of symbols in the game */
export const SYMBOL_COUNT = 10;

/** Wild/Scatter symbol ID (the Book) */
export const WSC = 10;

/**
 * Symbol definitions.
 * IDs match the Go source (1-10).
 * Tiers are used by the renderer for visual styling.
 */
export const symbols = [
  { id: 1,  name: 'Explorer', shortName: 'EXP', tier: 'premium',  baseColor: '#e8c840', accentColor: '#a08020' },
  { id: 2,  name: 'Mummy',    shortName: 'MUM', tier: 'premium',  baseColor: '#60b8e0', accentColor: '#3080a0' },
  { id: 3,  name: 'Statue',   shortName: 'STA', tier: 'mid',      baseColor: '#c07030', accentColor: '#804820' },
  { id: 4,  name: 'Scarab',   shortName: 'SCR', tier: 'mid',      baseColor: '#40b060', accentColor: '#208038' },
  { id: 5,  name: 'Ace',      shortName: 'A',   tier: 'low',      baseColor: '#d04040', accentColor: '#901818' },
  { id: 6,  name: 'King',     shortName: 'K',   tier: 'low',      baseColor: '#d08030', accentColor: '#905018' },
  { id: 7,  name: 'Queen',    shortName: 'Q',   tier: 'low',      baseColor: '#a050c0', accentColor: '#703088' },
  { id: 8,  name: 'Jack',     shortName: 'J',   tier: 'low',      baseColor: '#4080d0', accentColor: '#284898' },
  { id: 9,  name: 'Ten',      shortName: '10',  tier: 'low',      baseColor: '#50b050', accentColor: '#308030' },
  { id: 10, name: 'Book',     shortName: 'BK',  tier: 'scatter',  baseColor: '#ffd700', accentColor: '#b89800' },
];

/**
 * Lined payment table.
 *
 * linePay[symbolIndex][count - 1] → payout multiplier
 * Index 0 = symbol 1 (Explorer), Index 9 = symbol 10 (Book)
 *
 * Direct copy from Go source:
 *   var LinePay = [sn][5]float64{...}
 */
export const linePay = [
  [0, 10, 100, 1000, 5000], //  1 explorer
  [0, 5,  40,  400,  2000], //  2 mummy
  [0, 5,  30,  100,  750],  //  3 statue
  [0, 5,  30,  100,  750],  //  4 scarab
  [0, 0,  5,   40,   150],  //  5 ace
  [0, 0,  5,   40,   150],  //  6 king
  [0, 0,  5,   25,   100],  //  7 queen
  [0, 0,  5,   25,   100],  //  8 jack
  [0, 0,  5,   25,   100],  //  9 ten
  [0, 0,  0,   0,    0],    // 10 book — pays via scatter only
];

/**
 * Scatter payment table.
 * scatPay[count - 1] → payout multiplier (multiplied by total bet)
 *
 * From Go: var ScatPay = [5]float64{0, 0, 2, 20, 200}
 */
export const scatPay = [0, 0, 2, 20, 200];

/**
 * Scatter free spin awards.
 * scatFreespin[count - 1] → number of free spins
 *
 * From Go: var ScatFreespin = [5]int{0, 0, 10, 10, 10}
 */
export const scatFreespin = [0, 0, 10, 10, 10];

/** Available bet denominations */
export const betValues = [1, 2, 5, 10, 20, 50, 100];
