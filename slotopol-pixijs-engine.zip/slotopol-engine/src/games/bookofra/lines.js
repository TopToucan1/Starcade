/**
 * Book of Ra — Bet line definitions.
 *
 * 10-line Novomatic pattern (first 10 of BetLinesNvm5x3v1).
 * Each line is an array of 5 values (one per reel column).
 * Values are 1-based row positions (1=top, 2=middle, 3=bottom).
 *
 * Ported from: game/slot/lines.go — BetLinesNvm5x3v1[:10]
 */

export const lines = [
  [2, 2, 2, 2, 2], //  1 — middle row
  [1, 1, 1, 1, 1], //  2 — top row
  [3, 3, 3, 3, 3], //  3 — bottom row
  [1, 2, 3, 2, 1], //  4 — V shape
  [3, 2, 1, 2, 3], //  5 — inverted V
  [2, 3, 3, 3, 2], //  6 — shallow bottom
  [2, 1, 1, 1, 2], //  7 — shallow top
  [3, 3, 2, 1, 1], //  8 — descending
  [1, 1, 2, 3, 3], //  9 — ascending
  [3, 2, 2, 2, 1], // 10 — slight descent
];

/**
 * Line colors for rendering (one per line).
 * Matches common Novomatic visual style.
 */
export const lineColors = [
  0xe8c840, // 1  gold
  0x60b8e0, // 2  blue
  0xc07030, // 3  bronze
  0x40b060, // 4  green
  0xd04040, // 5  red
  0xd08030, // 6  orange
  0xa050c0, // 7  purple
  0x4080d0, // 8  sky blue
  0x50b050, // 9  lime
  0xf0f0f0, // 10 white
];
