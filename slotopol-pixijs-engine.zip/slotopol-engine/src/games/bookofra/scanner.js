/**
 * Book of Ra — Game-specific scanner and lifecycle hooks.
 *
 * Ported from: game/slot/novomatic/bookofra/bookofra_rule.go
 * Functions: Scanner(), ScanLined(), ScanScatters(), Prepare(), Apply()
 */

import { scanLinedWins, scanExpandingWins, scanScatterWins } from '../../engine/WinScanner.js';
import { linePay, scatPay, scatFreespin, WSC } from './paytable.js';
import { lines } from './lines.js';

/**
 * Main scanner — detects all wins on the current grid.
 *
 * Mirrors Go: func (g *Game) Scanner(wins *slot.Wins) error
 *
 * Combines three scan passes:
 * 1. Lined wins (left-to-right matches with wild substitution)
 * 2. Expanding symbol wins (during free spins only)
 * 3. Scatter wins (3+ Books anywhere)
 *
 * @param {SlotEngine} engine
 * @returns {Object[]} Array of win objects
 */
export function scanner(engine) {
  const wins = [];

  // 1. Scan lined wins
  const linedWins = scanLinedWins(engine, {
    lines,
    linePay,
    wildSym: WSC,
    expandSym: engine.state.es || 0,
  });
  wins.push(...linedWins);

  // 2. Scan expanding symbol wins (free spins only)
  if (engine.state.es > 0) {
    const expandWins = scanExpandingWins(engine, {
      expandSym: engine.state.es,
      lines,
      linePay,
    });
    wins.push(...expandWins);
  }

  // 3. Scan scatter wins
  const scatWins = scanScatterWins(engine, {
    scatSym: WSC,
    scatPay,
    scatFreespin,
    minCount: 3,
  });
  wins.push(...scatWins);

  return wins;
}


/**
 * Prepare — called before each spin.
 *
 * Mirrors Go: func (g *Game) Prepare()
 *
 * Clears the expanding symbol when not in free spins mode.
 *
 * @param {SlotEngine} engine
 */
export function prepare(engine) {
  if (engine.state.fsr === 0) {
    engine.state.es = 0;
  }
}


/**
 * Apply — called after each spin with the win results.
 *
 * Mirrors Go: func (g *Game) Apply(wins slot.Wins)
 *
 * When entering free spins, picks a random expanding symbol (1–9).
 * This symbol will expand to fill entire reels during free games.
 *
 * @param {SlotEngine} engine
 * @param {Object[]} wins - Array of win objects from scanner
 */
export function apply(engine, wins) {
  // If in free spins and no expanding symbol is set yet, pick one
  if (engine.state.fsr > 0 && (!engine.state.es || engine.state.es === 0)) {
    // Random symbol 1–9 (not the Book/scatter)
    engine.state.es = Math.floor(Math.random() * 9) + 1;
  }
}
