/**
 * UIController — Manages HTML UI elements and binds them to the engine.
 *
 * Handles:
 * - Balance, bet, lines, win displays
 * - Button click handlers
 * - Keyboard shortcuts
 * - Free spin banner
 * - Big win popup
 * - Enable/disable states during spins
 */

export class UIController {
  /**
   * @param {SlotEngine} engine
   * @param {Object} elements - Map of DOM element IDs
   */
  constructor(engine, elements = {}) {
    this.engine = engine;

    // DOM elements (with defaults)
    this.els = {
      balance:     document.getElementById(elements.balance || 'balance-display'),
      lines:       document.getElementById(elements.lines || 'lines-display'),
      bet:         document.getElementById(elements.bet || 'bet-display'),
      totalBet:    document.getElementById(elements.totalBet || 'totalbet-display'),
      win:         document.getElementById(elements.win || 'win-value-display'),
      rtp:         document.getElementById(elements.rtp || 'rtp-display'),
      btnSpin:     document.getElementById(elements.btnSpin || 'btn-spin'),
      btnLinesUp:  document.getElementById(elements.btnLinesUp || 'btn-lines-up'),
      btnLinesDown:document.getElementById(elements.btnLinesDown || 'btn-lines-down'),
      btnBetUp:    document.getElementById(elements.btnBetUp || 'btn-bet-up'),
      btnBetDown:  document.getElementById(elements.btnBetDown || 'btn-bet-down'),
      fsBanner:    document.getElementById(elements.fsBanner || 'free-spin-banner'),
      fsCount:     document.getElementById(elements.fsCount || 'fs-count'),
      winDisplay:  document.getElementById(elements.winDisplay || 'win-display'),
    };

    // Callbacks
    this.onSpin = null;  // Set externally: () => void

    this._bindEvents();
    this.update();
  }

  /** Bind button click handlers and keyboard shortcuts */
  _bindEvents() {
    // Spin
    if (this.els.btnSpin) {
      this.els.btnSpin.addEventListener('click', () => {
        if (this.onSpin) this.onSpin();
      });
    }

    // Lines
    if (this.els.btnLinesUp) {
      this.els.btnLinesUp.addEventListener('click', () => {
        this.engine.selUp();
        this.update();
      });
    }
    if (this.els.btnLinesDown) {
      this.els.btnLinesDown.addEventListener('click', () => {
        this.engine.selDown();
        this.update();
      });
    }

    // Bet
    if (this.els.btnBetUp) {
      this.els.btnBetUp.addEventListener('click', () => {
        this.engine.betUp();
        this.update();
      });
    }
    if (this.els.btnBetDown) {
      this.els.btnBetDown.addEventListener('click', () => {
        this.engine.betDown();
        this.update();
      });
    }

    // Keyboard: Space to spin
    document.addEventListener('keydown', (e) => {
      if (e.code === 'Space' && !e.repeat) {
        e.preventDefault();
        if (this.onSpin) this.onSpin();
      }
    });
  }

  /** Update all display values from engine state */
  update() {
    const s = this.engine.state;

    if (this.els.balance) this.els.balance.textContent = s.balance.toFixed(2);
    if (this.els.lines) this.els.lines.textContent = s.sel;
    if (this.els.bet) this.els.bet.textContent = s.bet;
    if (this.els.totalBet) this.els.totalBet.textContent = this.engine.cost().toFixed(0);
    if (this.els.win) this.els.win.textContent = s.gain > 0 ? s.gain.toFixed(0) : '0';

    // RTP display
    if (this.els.rtp) {
      const rtpKey = this.engine.config.selectedRTP;
      this.els.rtp.textContent = parseFloat(rtpKey).toFixed(2);
    }

    // Free spin banner
    if (this.els.fsBanner) {
      if (s.fsr > 0) {
        this.els.fsBanner.classList.add('visible');
        if (this.els.fsCount) this.els.fsCount.textContent = s.fsr;
      } else {
        this.els.fsBanner.classList.remove('visible');
      }
    }

    // Button enabled/disabled states
    const canSpin = this.engine.canSpin();
    const inFS = this.engine.freeMode();
    if (this.els.btnSpin) this.els.btnSpin.disabled = !canSpin;
    if (this.els.btnLinesUp) this.els.btnLinesUp.disabled = inFS;
    if (this.els.btnLinesDown) this.els.btnLinesDown.disabled = inFS;
    if (this.els.btnBetUp) this.els.btnBetUp.disabled = inFS;
    if (this.els.btnBetDown) this.els.btnBetDown.disabled = inFS;
  }

  /** Disable all controls during spin animation */
  setSpinning(isSpinning) {
    if (this.els.btnSpin) this.els.btnSpin.disabled = isSpinning;
    if (this.els.btnLinesUp) this.els.btnLinesUp.disabled = isSpinning;
    if (this.els.btnLinesDown) this.els.btnLinesDown.disabled = isSpinning;
    if (this.els.btnBetUp) this.els.btnBetUp.disabled = isSpinning;
    if (this.els.btnBetDown) this.els.btnBetDown.disabled = isSpinning;
  }

  /** Show the big win popup */
  showBigWin(amount) {
    if (!this.els.winDisplay) return;
    this.els.winDisplay.textContent = amount.toFixed(0);
    this.els.winDisplay.classList.add('visible');
    setTimeout(() => {
      this.els.winDisplay.classList.remove('visible');
    }, 2500);
  }

  /** Hide the big win popup */
  hideBigWin() {
    if (this.els.winDisplay) {
      this.els.winDisplay.classList.remove('visible');
    }
  }
}
