/**
 * WinScanner — Reusable win-scanning utility functions.
 *
 * These cover the most common slot mechanics found across games.
 * Game-specific scanners compose these building blocks.
 *
 * Ported from patterns in: github.com/slotopol/server/game/slot/
 */

/**
 * Scan for lined (left-to-right) wins.
 *
 * Standard Novomatic-style line scanning:
 * - Wild symbol substitutes for any regular symbol
 * - Matches must start from leftmost reel
 * - Longest match wins per line
 *
 * Ported from: bookofra_rule.go ScanLined (generalized)
 *
 * @param {SlotEngine} engine - The engine instance
 * @param {Object} opts
 * @param {number[][]} opts.lines - Bet line definitions (1-based)
 * @param {number[][]} opts.linePay - Pay table [symIdx][count-1] → multiplier
 * @param {number} opts.wildSym - Wild symbol ID
 * @param {number} [opts.expandSym=0] - Expanding symbol ID (0 = none)
 * @returns {Object[]} Array of WinItem objects
 */
export function scanLinedWins(engine, { lines, linePay, wildSym, expandSym = 0 }) {
  const wins = [];
  const grid = engine.state.grid;
  const bet = engine.state.bet;
  const sel = engine.state.sel;
  const activeLine = lines.slice(0, sel);
  const cols = engine.cols;

  for (let li = 0; li < activeLine.length; li++) {
    const line = activeLine[li];
    let numw = 0;   // number of leading wilds
    let numl = cols; // length of match
    let syml = 0;    // matched symbol

    for (let x = 1; x <= cols; x++) {
      const sx = grid[x - 1][line[x - 1] - 1];

      if (sx === wildSym) {
        // Wild: if no symbol matched yet, count as leading wild
        if (syml === 0) numw = x;
      } else if (syml === 0) {
        // First non-wild symbol
        // If this is the expanding symbol and there are no leading wilds, break
        if (sx === expandSym && numw === 0) break;
        syml = sx;
      } else if (sx !== syml) {
        // Mismatch: line ends here
        numl = x - 1;
        break;
      }
    }

    if (numl >= 2 && syml > 0) {
      const payl = linePay[syml - 1][numl - 1];
      if (payl > 0) {
        const xy = [];
        for (let x = 0; x < numl; x++) {
          xy.push([x + 1, line[x]]);
        }
        wins.push({
          pay: bet * payl,
          mp: 1,
          sym: syml,
          num: numl,
          li: li + 1,
          xy,
          fs: 0,
        });
      }
    }
  }

  return wins;
}


/**
 * Scan for expanding symbol wins.
 *
 * During free spins in games like Book of Ra, a special symbol
 * expands to fill entire reels. All instances anywhere on the grid
 * count, and pay on every active line.
 *
 * Ported from: bookofra_rule.go (expanding symbol section of ScanLined)
 *
 * @param {SlotEngine} engine
 * @param {Object} opts
 * @param {number} opts.expandSym - The expanding symbol ID
 * @param {number[][]} opts.lines - Bet line definitions
 * @param {number[][]} opts.linePay - Pay table
 * @returns {Object[]} Array of WinItem objects
 */
export function scanExpandingWins(engine, { expandSym, lines, linePay }) {
  if (!expandSym || expandSym === 0) return [];

  const wins = [];
  const grid = engine.state.grid;
  const bet = engine.state.bet;
  const sel = engine.state.sel;
  const activeLine = lines.slice(0, sel);

  // Count expanding symbol appearances on entire grid
  let count = 0;
  const positions = [];
  for (let x = 0; x < engine.cols; x++) {
    for (let y = 0; y < engine.rows; y++) {
      if (grid[x][y] === expandSym) {
        count++;
        positions.push([x + 1, y + 1]);
      }
    }
  }

  if (count < 2) return [];

  const paye = linePay[expandSym - 1][count - 1];
  if (paye === 0) return [];

  // Pay on every active line
  for (let li = 0; li < activeLine.length; li++) {
    const line = activeLine[li];
    // Map hit positions to the line's row positions
    const xyLine = positions.map(h => [h[0], line[h[0] - 1]]);
    wins.push({
      pay: bet * paye,
      mp: 1,
      sym: expandSym,
      num: count,
      li: li + 1,
      xy: xyLine,
      fs: 0,
    });
  }

  return wins;
}


/**
 * Scan for scatter wins.
 *
 * Scatters pay regardless of line position — any N symbols
 * anywhere on the grid trigger a win and/or free spins.
 *
 * Ported from: bookofra_rule.go ScanScatters (generalized)
 *
 * @param {SlotEngine} engine
 * @param {Object} opts
 * @param {number} opts.scatSym - Scatter symbol ID
 * @param {number[]} opts.scatPay - Scatter pay table [count-1] → multiplier
 * @param {number[]} opts.scatFreespin - Free spins table [count-1] → FS count
 * @param {number} [opts.minCount=3] - Minimum scatters to trigger
 * @returns {Object[]} Array of WinItem objects
 */
export function scanScatterWins(engine, { scatSym, scatPay, scatFreespin, minCount = 3 }) {
  const wins = [];
  const grid = engine.state.grid;
  const bet = engine.state.bet;
  const sel = engine.state.sel;

  let count = 0;
  const positions = [];
  for (let x = 0; x < engine.cols; x++) {
    for (let y = 0; y < engine.rows; y++) {
      if (grid[x][y] === scatSym) {
        count++;
        positions.push([x + 1, y + 1]);
      }
    }
  }

  if (count >= minCount) {
    const pay = scatPay[count - 1] || 0;
    const fs = scatFreespin[count - 1] || 0;
    wins.push({
      pay: bet * sel * pay,
      mp: 1,
      sym: scatSym,
      num: count,
      li: 0, // 0 = scatter (no specific line)
      xy: positions,
      fs,
    });
  }

  return wins;
}


/**
 * Scan for right-to-left lined wins.
 *
 * Same as scanLinedWins but matching from the rightmost reel.
 * Used by some Novomatic and NetEnt games that pay both ways.
 *
 * @param {SlotEngine} engine
 * @param {Object} opts - Same as scanLinedWins
 * @returns {Object[]} Array of WinItem objects
 */
export function scanLinedWinsRTL(engine, { lines, linePay, wildSym }) {
  const wins = [];
  const grid = engine.state.grid;
  const bet = engine.state.bet;
  const sel = engine.state.sel;
  const activeLine = lines.slice(0, sel);
  const cols = engine.cols;

  for (let li = 0; li < activeLine.length; li++) {
    const line = activeLine[li];
    let numw = 0;
    let numl = cols;
    let syml = 0;

    for (let x = cols; x >= 1; x--) {
      const sx = grid[x - 1][line[x - 1] - 1];

      if (sx === wildSym) {
        if (syml === 0) numw = cols - x + 1;
      } else if (syml === 0) {
        syml = sx;
      } else if (sx !== syml) {
        numl = cols - x;
        break;
      }
    }

    if (numl >= 2 && syml > 0) {
      const payl = linePay[syml - 1][numl - 1];
      if (payl > 0) {
        const xy = [];
        for (let x = cols; x > cols - numl; x--) {
          xy.push([x, line[x - 1]]);
        }
        wins.push({
          pay: bet * payl,
          mp: 1,
          sym: syml,
          num: numl,
          li: li + 1,
          xy,
          fs: 0,
        });
      }
    }
  }

  return wins;
}
