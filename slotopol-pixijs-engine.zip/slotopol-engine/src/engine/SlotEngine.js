/**
 * SlotEngine — Universal slot game engine.
 *
 * Manages game state, spin cycle, balance, and delegates to
 * game-specific config for scanning, preparing, and applying.
 *
 * Ported from: github.com/slotopol/server/game/slot/slot.go
 *
 * Usage:
 *   import { SlotEngine } from './SlotEngine.js';
 *   import { BookOfRaConfig } from '../games/bookofra/index.js';
 *   const engine = new SlotEngine(BookOfRaConfig);
 *   const result = engine.doSpin();
 */

export class SlotEngine {
  /**
   * @param {Object} config — Game definition object (see README for format)
   */
  constructor(config) {
    this.config = config;
    this.cols = config.grid.cols;
    this.rows = config.grid.rows;

    // Core game state — mirrors Go's Slotx struct
    this.state = {
      balance: 1000,
      bet: config.betValues ? config.betValues[0] : 1,
      sel: config.lines.length,   // selected bet lines
      gain: 0,                     // last spin gain
      fsn: 0,                      // free spin number (count of FS played)
      fsr: 0,                      // free spins remaining
      grid: [],                    // current symbol grid [col][row]
      spinning: false,
      // Game-specific state gets merged from config.initialState
      ...(config.initialState || {}),
    };
  }

  /** Cost of one spin: bet × selected lines. Mirrors Go Slotx.Cost() */
  cost() {
    return this.state.bet * this.state.sel;
  }

  /** True if currently in free spin mode. Mirrors Go Slotx.FreeMode() */
  freeMode() {
    return this.state.fsr > 0;
  }

  /** Get the active reel strips based on game mode and selected RTP */
  getReels() {
    if (this.freeMode() && this.config.reelsBon) {
      return this.config.reelsBon;
    }
    const rtpKey = this.config.selectedRTP;
    return this.config.reelsMap[rtpKey] || Object.values(this.config.reelsMap)[0];
  }

  /**
   * Spin the reels — pick a random start position on each reel strip
   * and fill the visible grid.
   *
   * Mirrors Go's Grid5x3.SpinReels() behavior.
   * Returns the new grid.
   */
  spinReels() {
    const reels = this.getReels();
    const grid = [];
    for (let x = 0; x < this.cols; x++) {
      const reel = reels[x];
      const pos = Math.floor(Math.random() * reel.length);
      const col = [];
      for (let y = 0; y < this.rows; y++) {
        col.push(reel[(pos + y) % reel.length]);
      }
      grid.push(col);
    }
    this.state.grid = grid;
    return grid;
  }

  /**
   * Get symbol at grid position (1-based indexing, matching Go source).
   * lx(x, line) returns the symbol at column x, row defined by line[x-1].
   *
   * Mirrors Go's Grid5x3.LX(x, line)
   */
  lx(x, line) {
    return this.state.grid[x - 1][line[x - 1] - 1];
  }

  /**
   * Count how many times a symbol appears on the entire grid.
   * Mirrors Go's Grid5x3.SymNum(sym)
   */
  symNum(sym) {
    let count = 0;
    for (let x = 0; x < this.cols; x++) {
      for (let y = 0; y < this.rows; y++) {
        if (this.state.grid[x][y] === sym) count++;
      }
    }
    return count;
  }

  /**
   * Get all positions of a symbol on the grid.
   * Returns array of [col, row] pairs (1-based).
   * Mirrors Go's Grid5x3.SymPos(sym)
   */
  symPos(sym) {
    const hits = [];
    for (let x = 0; x < this.cols; x++) {
      for (let y = 0; y < this.rows; y++) {
        if (this.state.grid[x][y] === sym) {
          hits.push([x + 1, y + 1]);
        }
      }
    }
    return hits;
  }

  /**
   * Run the game-specific win scanner.
   * Delegates to config.scanner(engine).
   * Returns array of WinItem objects.
   */
  scan() {
    return this.config.scanner(this);
  }

  /**
   * Execute a full spin cycle.
   * Returns null if spin cannot proceed (insufficient balance, already spinning).
   *
   * Pipeline mirrors Go server's API spin handler:
   *   prepare → deduct → spin → scan → apply → credit
   *
   * @returns {{ grid: number[][], wins: Object[], gain: number, fsr: number, fsn: number } | null}
   */
  doSpin() {
    if (this.state.spinning) return null;

    // 1. Prepare — game-specific pre-spin logic
    this.config.prepare(this);

    // 2. Deduct cost (not in free mode)
    if (!this.freeMode()) {
      if (this.state.balance < this.cost()) return null;
      this.state.balance -= this.cost();
    } else {
      this.state.fsr--;
      this.state.fsn++;
    }

    // 3. Spin reels
    this.spinReels();

    // 4. Scan for wins
    const wins = this.scan();

    // 5. Calculate totals
    let totalGain = 0;
    let totalFS = 0;
    for (const w of wins) {
      totalGain += w.pay * w.mp;
      totalFS += w.fs || 0;
    }

    // 6. Apply — game-specific post-spin logic
    this.config.apply(this, wins);

    // 7. Award free spins
    if (totalFS > 0) {
      this.state.fsr += totalFS;
    }

    // 8. Credit winnings
    this.state.balance += totalGain;
    this.state.gain = totalGain;

    return {
      grid: this.state.grid,
      wins,
      gain: totalGain,
      fsr: this.state.fsr,
      fsn: this.state.fsn,
    };
  }

  // ── Bet & line controls ──

  setBet(value) {
    const vals = this.config.betValues || [1];
    if (vals.includes(value)) {
      this.state.bet = value;
      return true;
    }
    return false;
  }

  betUp() {
    const vals = this.config.betValues || [1];
    const idx = vals.indexOf(this.state.bet);
    if (idx < vals.length - 1) {
      this.state.bet = vals[idx + 1];
      return true;
    }
    return false;
  }

  betDown() {
    const vals = this.config.betValues || [1];
    const idx = vals.indexOf(this.state.bet);
    if (idx > 0) {
      this.state.bet = vals[idx - 1];
      return true;
    }
    return false;
  }

  setSel(sel) {
    if (sel >= 1 && sel <= this.config.lines.length) {
      this.state.sel = sel;
      return true;
    }
    return false;
  }

  selUp() {
    return this.setSel(this.state.sel + 1);
  }

  selDown() {
    return this.setSel(this.state.sel - 1);
  }

  /** Check if a spin is currently affordable */
  canSpin() {
    return this.freeMode() || this.state.balance >= this.cost();
  }

  /** Get available RTP options */
  getAvailableRTPs() {
    return Object.keys(this.config.reelsMap);
  }

  /** Set the active RTP */
  setRTP(rtpKey) {
    if (this.config.reelsMap[rtpKey]) {
      this.config.selectedRTP = rtpKey;
      return true;
    }
    return false;
  }
}
