/**
 * ReelDisplay — Manages the reel grid rendering and spin animation.
 *
 * Handles:
 * - Displaying the current symbol grid
 * - Spin animation with staggered reel stopping
 * - Symbol scrolling effect during spins
 */

export class ReelDisplay {
  /**
   * @param {PIXI.Application} app
   * @param {Object} opts
   * @param {number} opts.cols - Number of reel columns
   * @param {number} opts.rows - Number of visible rows
   * @param {number} opts.cellW - Cell width in pixels
   * @param {number} opts.cellH - Cell height in pixels
   * @param {number} opts.gridX - X offset of the grid
   * @param {number} opts.gridY - Y offset of the grid
   * @param {Object} opts.textures - Symbol ID → PIXI.Texture map
   * @param {number} opts.symbolCount - Total number of symbols (for random during spin)
   */
  constructor(app, opts) {
    this.app = app;
    this.cols = opts.cols;
    this.rows = opts.rows;
    this.cellW = opts.cellW;
    this.cellH = opts.cellH;
    this.gridX = opts.gridX;
    this.gridY = opts.gridY;
    this.textures = opts.textures;
    this.symbolCount = opts.symbolCount;

    // Animation settings
    this.spinSpeed = 35;
    this.spinBaseTime = 400;    // ms for first reel
    this.spinStagger = 180;     // ms between reel stops
    this.extraRows = 6;         // extra sprites per reel for scrolling

    // State
    this.spinning = false;
    this.reelContainers = [];
    this.symbolSprites = [];    // [col][row]

    this._build();
  }

  /** Build the reel containers, masks, and sprites */
  _build() {
    // Background frame
    this.bgGfx = new PIXI.Graphics();
    this.bgGfx.beginFill(0x100e08);
    this.bgGfx.drawRoundedRect(
      this.gridX - 12, this.gridY - 12,
      this.cols * this.cellW + 24, this.rows * this.cellH + 24, 12
    );
    this.bgGfx.endFill();
    this.bgGfx.lineStyle(2, 0x302818, 0.6);
    this.bgGfx.drawRoundedRect(
      this.gridX - 12, this.gridY - 12,
      this.cols * this.cellW + 24, this.rows * this.cellH + 24, 12
    );
    // Reel separators
    for (let i = 1; i < this.cols; i++) {
      this.bgGfx.lineStyle(1, 0x282010, 0.5);
      this.bgGfx.moveTo(this.gridX + i * this.cellW, this.gridY - 6);
      this.bgGfx.lineTo(this.gridX + i * this.cellW, this.gridY + this.rows * this.cellH + 6);
    }
    this.app.stage.addChild(this.bgGfx);

    // Build each reel column
    for (let x = 0; x < this.cols; x++) {
      const container = new PIXI.Container();
      container.x = this.gridX + x * this.cellW;
      container.y = this.gridY;

      // Mask to clip sprites to visible area
      const mask = new PIXI.Graphics();
      mask.beginFill(0xffffff);
      mask.drawRect(0, 0, this.cellW, this.rows * this.cellH);
      mask.endFill();
      mask.x = container.x;
      mask.y = container.y;
      container.mask = mask;

      // Create sprites (visible rows + extra for scrolling)
      const sprites = [];
      for (let y = 0; y < this.extraRows; y++) {
        const sprite = new PIXI.Sprite(this.textures[1]);
        sprite.x = 4;
        sprite.y = y * this.cellH;
        sprite.width = this.cellW - 8;
        sprite.height = this.cellH - 8;
        container.addChild(sprite);
        sprites.push(sprite);
      }

      this.symbolSprites.push(sprites);
      this.reelContainers.push(container);
      this.app.stage.addChild(mask);
      this.app.stage.addChild(container);
    }
  }

  /**
   * Display a grid immediately (no animation).
   * @param {number[][]} grid - [col][row] of symbol IDs
   */
  displayGrid(grid) {
    for (let x = 0; x < this.cols; x++) {
      for (let y = 0; y < this.rows; y++) {
        const sprite = this.symbolSprites[x][y];
        sprite.texture = this.textures[grid[x][y]];
        sprite.y = y * this.cellH;
        sprite.alpha = 1;
      }
      // Hide extra sprites
      for (let y = this.rows; y < this.extraRows; y++) {
        this.symbolSprites[x][y].alpha = 0;
      }
    }
  }

  /**
   * Start the spin animation, then display the final result grid.
   *
   * @param {number[][]} targetGrid - The final grid to display after animation
   * @returns {Promise} Resolves when all reels have stopped
   */
  startSpin(targetGrid) {
    return new Promise((resolve) => {
      this.spinning = true;
      const baseTime = performance.now();
      const reelStates = [];

      for (let x = 0; x < this.cols; x++) {
        reelStates.push({
          spinning: true,
          offset: 0,
          stopTime: baseTime + this.spinBaseTime + x * this.spinStagger,
          stopped: false,
        });
      }

      const getRandomSym = () => Math.floor(Math.random() * this.symbolCount) + 1;

      const animate = (now) => {
        let allStopped = true;

        for (let x = 0; x < this.cols; x++) {
          const rs = reelStates[x];
          if (rs.stopped) continue;

          if (now >= rs.stopTime) {
            // Stop: show final symbols
            rs.stopped = true;
            for (let y = 0; y < this.rows; y++) {
              const sprite = this.symbolSprites[x][y];
              sprite.texture = this.textures[targetGrid[x][y]];
              sprite.y = y * this.cellH;
              sprite.alpha = 1;
            }
            for (let y = this.rows; y < this.extraRows; y++) {
              this.symbolSprites[x][y].alpha = 0;
            }
            continue;
          }

          allStopped = false;

          // Scrolling animation
          rs.offset += this.spinSpeed;
          if (rs.offset >= this.cellH) {
            rs.offset -= this.cellH;
            // Shift symbols down, add random at top
            for (let y = this.extraRows - 1; y > 0; y--) {
              this.symbolSprites[x][y].texture = this.symbolSprites[x][y - 1].texture;
            }
            this.symbolSprites[x][0].texture = this.textures[getRandomSym()];
          }

          // Position all sprites with scroll offset
          for (let y = 0; y < this.extraRows; y++) {
            this.symbolSprites[x][y].y = y * this.cellH - (this.rows * this.cellH) + rs.offset;
            this.symbolSprites[x][y].alpha = 1;
          }
        }

        if (!allStopped) {
          requestAnimationFrame(animate);
        } else {
          this.spinning = false;
          resolve();
        }
      };

      requestAnimationFrame(animate);
    });
  }

  /**
   * Update textures (e.g., when switching games).
   * @param {Object} textures - New symbol ID → PIXI.Texture map
   * @param {number} symbolCount - New symbol count
   */
  updateTextures(textures, symbolCount) {
    this.textures = textures;
    this.symbolCount = symbolCount;
  }
}
