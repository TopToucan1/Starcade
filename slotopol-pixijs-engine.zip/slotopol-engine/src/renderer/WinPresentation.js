/**
 * WinPresentation — Renders win lines, symbol highlights, and big win effects.
 */

export class WinPresentation {
  /**
   * @param {PIXI.Application} app
   * @param {Object} opts
   * @param {number} opts.gridX
   * @param {number} opts.gridY
   * @param {number} opts.cellW
   * @param {number} opts.cellH
   * @param {number} opts.cols
   * @param {number} opts.rows
   * @param {number[][]} opts.lines - Bet line definitions
   * @param {number[]} opts.lineColors - Colors per line
   */
  constructor(app, opts) {
    this.app = app;
    this.gridX = opts.gridX;
    this.gridY = opts.gridY;
    this.cellW = opts.cellW;
    this.cellH = opts.cellH;
    this.cols = opts.cols;
    this.rows = opts.rows;
    this.lines = opts.lines;
    this.lineColors = opts.lineColors;

    // Win lines overlay
    this.linesGfx = new PIXI.Graphics();
    this.linesGfx.zIndex = 100;
    this.app.stage.addChild(this.linesGfx);

    // Highlight overlay
    this.highlightContainer = new PIXI.Container();
    this.highlightContainer.zIndex = 90;
    this.app.stage.addChild(this.highlightContainer);

    // Line number indicators
    this.lineIndicators = new PIXI.Container();
    this.lineIndicators.zIndex = 80;
    this.app.stage.addChild(this.lineIndicators);
  }

  /**
   * Build line number indicators on left and right of the grid.
   * Call once after construction (or when lines change).
   */
  buildLineIndicators() {
    this.lineIndicators.removeChildren();

    for (let i = 0; i < this.lines.length; i++) {
      const line = this.lines[i];
      const y = this.gridY + (line[0] - 1) * this.cellH + this.cellH / 2;
      const color = this.lineColors[i % this.lineColors.length];

      // Left indicator
      const lg = new PIXI.Graphics();
      lg.beginFill(color, 0.7);
      lg.drawRoundedRect(0, 0, 18, 16, 3);
      lg.endFill();
      lg.x = this.gridX - 30;
      lg.y = y - 8;

      const lt = new PIXI.Text(`${i + 1}`, {
        fontFamily: 'Cinzel, Georgia, serif', fontSize: 10,
        fontWeight: '700', fill: '#0a0806',
      });
      lt.anchor.set(0.5);
      lt.x = lg.x + 9;
      lt.y = lg.y + 8;

      // Right indicator
      const rg = new PIXI.Graphics();
      rg.beginFill(color, 0.7);
      rg.drawRoundedRect(0, 0, 18, 16, 3);
      rg.endFill();
      rg.x = this.gridX + this.cols * this.cellW + 12;
      rg.y = y - 8;

      const rt = new PIXI.Text(`${i + 1}`, {
        fontFamily: 'Cinzel, Georgia, serif', fontSize: 10,
        fontWeight: '700', fill: '#0a0806',
      });
      rt.anchor.set(0.5);
      rt.x = rg.x + 9;
      rt.y = rg.y + 8;

      this.lineIndicators.addChild(lg, lt, rg, rt);
    }
  }

  /**
   * Show win lines and highlights for the given wins.
   * @param {Object[]} wins - Array of WinItem objects from the scanner
   */
  showWins(wins) {
    this.clear();

    const highlightPositions = new Set();

    for (const win of wins) {
      // Draw win line
      if (win.li > 0 && win.li <= this.lines.length) {
        const line = this.lines[win.li - 1];
        const color = this.lineColors[(win.li - 1) % this.lineColors.length];

        this.linesGfx.lineStyle(3, color, 0.7);
        for (let x = 0; x < this.cols; x++) {
          const px = this.gridX + x * this.cellW + this.cellW / 2;
          const py = this.gridY + (line[x] - 1) * this.cellH + this.cellH / 2;
          if (x === 0) this.linesGfx.moveTo(px, py);
          else this.linesGfx.lineTo(px, py);
        }
      }

      // Highlight winning symbol positions
      for (const [hx, hy] of win.xy) {
        const key = `${hx - 1},${hy - 1}`;
        if (highlightPositions.has(key)) continue;
        highlightPositions.add(key);

        const glow = new PIXI.Graphics();
        glow.beginFill(0xffd700, 0.15);
        glow.lineStyle(2, 0xffd700, 0.6);
        glow.drawRoundedRect(
          this.gridX + (hx - 1) * this.cellW + 2,
          this.gridY + (hy - 1) * this.cellH + 2,
          this.cellW - 4, this.cellH - 4, 8
        );
        glow.endFill();
        this.highlightContainer.addChild(glow);
      }
    }
  }

  /**
   * Clear all win lines and highlights.
   */
  clear() {
    this.linesGfx.clear();
    this.highlightContainer.removeChildren();
  }

  /**
   * Update line definitions (e.g., when switching games).
   */
  setLines(lines, lineColors) {
    this.lines = lines;
    this.lineColors = lineColors;
    this.buildLineIndicators();
  }
}
