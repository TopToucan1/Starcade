/**
 * SlotRenderer — Main PixiJS renderer that orchestrates all visual components.
 *
 * Manages:
 * - PixiJS application lifecycle
 * - Canvas scaling / responsive resize
 * - Symbol texture generation
 * - Reel display
 * - Win presentation
 */

import { SymbolFactory } from './SymbolFactory.js';
import { ReelDisplay } from './ReelDisplay.js';
import { WinPresentation } from './WinPresentation.js';

export class SlotRenderer {
  /**
   * @param {HTMLElement} container - DOM element to mount canvas into
   * @param {Object} opts
   * @param {number} [opts.width=960] - Logical canvas width
   * @param {number} [opts.height=640] - Logical canvas height
   * @param {number} [opts.cellW=140] - Symbol cell width
   * @param {number} [opts.cellH=140] - Symbol cell height
   */
  constructor(container, opts = {}) {
    this.width = opts.width || 960;
    this.height = opts.height || 640;
    this.cellW = opts.cellW || 140;
    this.cellH = opts.cellH || 140;
    this.container = container;

    // Create PixiJS app
    this.app = new PIXI.Application({
      width: this.width,
      height: this.height,
      backgroundColor: 0x0a0806,
      antialias: true,
      resolution: window.devicePixelRatio || 1,
      autoDensity: true,
    });
    container.appendChild(this.app.view);

    // Responsive scaling
    this._setupResize();

    // Sub-components (initialized when game is loaded)
    this.symbolFactory = new SymbolFactory(this.app, this.cellW, this.cellH);
    this.reelDisplay = null;
    this.winPresentation = null;
  }

  /**
   * Load a game config — generates textures and builds the reel display.
   * @param {Object} config - Game definition object
   */
  loadGame(config) {
    this.config = config;
    const cols = config.grid.cols;
    const rows = config.grid.rows;

    // Calculate grid position (centered)
    this.gridX = (this.width - cols * this.cellW) / 2;
    this.gridY = 50;

    // Generate symbol textures
    const textures = this.symbolFactory.generateAll(config.symbols);

    // Create reel display
    if (this.reelDisplay) {
      // TODO: cleanup previous display
    }
    this.reelDisplay = new ReelDisplay(this.app, {
      cols, rows,
      cellW: this.cellW,
      cellH: this.cellH,
      gridX: this.gridX,
      gridY: this.gridY,
      textures,
      symbolCount: config.symbols.length,
    });

    // Create win presentation
    this.winPresentation = new WinPresentation(this.app, {
      gridX: this.gridX,
      gridY: this.gridY,
      cellW: this.cellW,
      cellH: this.cellH,
      cols, rows,
      lines: config.lines,
      lineColors: config.lineColors,
    });
    this.winPresentation.buildLineIndicators();
  }

  /**
   * Display a grid immediately.
   * @param {number[][]} grid
   */
  displayGrid(grid) {
    if (this.reelDisplay) this.reelDisplay.displayGrid(grid);
  }

  /**
   * Start spin animation, then show final grid.
   * @param {number[][]} targetGrid
   * @returns {Promise}
   */
  async spin(targetGrid) {
    this.winPresentation.clear();
    await this.reelDisplay.startSpin(targetGrid);
  }

  /**
   * Show win lines and highlights.
   * @param {Object[]} wins
   */
  showWins(wins) {
    this.winPresentation.showWins(wins);
  }

  /** Clear win display */
  clearWins() {
    this.winPresentation.clear();
  }

  /** Handle responsive canvas scaling */
  _setupResize() {
    const resize = () => {
      const scale = Math.min(
        window.innerWidth / this.width,
        (window.innerHeight - 80) / this.height
      );
      this.app.view.style.width = `${this.width * scale}px`;
      this.app.view.style.height = `${this.height * scale}px`;
    };
    resize();
    window.addEventListener('resize', resize);
  }
}
