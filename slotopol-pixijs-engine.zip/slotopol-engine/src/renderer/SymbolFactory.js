/**
 * SymbolFactory — Procedural symbol texture generation.
 *
 * Generates visually distinct textures for each symbol type.
 * These are placeholder graphics — replace with real art assets
 * by swapping this factory for sprite sheet loading.
 *
 * Tiers: premium, mid, low, scatter — each gets a unique visual style.
 */

export class SymbolFactory {
  /**
   * @param {PIXI.Application} app - PixiJS app instance (for texture generation)
   * @param {number} cellW - Symbol cell width
   * @param {number} cellH - Symbol cell height
   */
  constructor(app, cellW, cellH) {
    this.app = app;
    this.cellW = cellW;
    this.cellH = cellH;
    this.textures = {};
  }

  /**
   * Generate textures for all symbols in a game config.
   * @param {Object[]} symbols - Array of symbol definitions
   * @returns {Object} Map of symbol ID → PIXI.Texture
   */
  generateAll(symbols) {
    this.textures = {};
    for (const sym of symbols) {
      this.textures[sym.id] = this.generateOne(sym);
    }
    return this.textures;
  }

  /**
   * Get texture for a symbol ID.
   * @param {number} id
   * @returns {PIXI.Texture}
   */
  get(id) {
    return this.textures[id];
  }

  /**
   * Generate a single symbol texture.
   * @param {Object} sym - Symbol definition
   * @returns {PIXI.Texture}
   */
  generateOne(sym) {
    const s = this.cellW - 8;
    const container = new PIXI.Container();

    switch (sym.tier) {
      case 'scatter':
        this._drawScatter(container, sym, s);
        break;
      case 'premium':
        this._drawPremium(container, sym, s);
        break;
      case 'mid':
        this._drawMid(container, sym, s);
        break;
      default:
        this._drawLow(container, sym, s);
        break;
    }

    return this.app.renderer.generateTexture(container);
  }

  /** Scatter (Book) — ornate golden rectangle with cross pattern */
  _drawScatter(container, sym, s) {
    const g = new PIXI.Graphics();
    // Dark background
    g.beginFill(0x1a1408);
    g.drawRoundedRect(4, 4, s, s, 10);
    g.endFill();
    // Outer border
    g.lineStyle(3, 0xffd700, 0.9);
    g.drawRoundedRect(10, 10, s - 12, s - 12, 6);
    // Inner border
    g.lineStyle(1.5, 0xb89800, 0.6);
    g.drawRoundedRect(18, 18, s - 28, s - 28, 4);
    // Cross pattern
    g.lineStyle(2, 0xffd700, 0.5);
    g.moveTo(s / 2 + 4, 30);
    g.lineTo(s / 2 + 4, s - 22);
    g.moveTo(30, s / 2 + 4);
    g.lineTo(s - 22, s / 2 + 4);
    // Center glow
    g.beginFill(0xffd700, 0.8);
    g.drawCircle(s / 2 + 4, s / 2 + 4, 8);
    g.endFill();
    g.beginFill(0xffffff, 0.5);
    g.drawCircle(s / 2 + 4, s / 2 + 4, 3);
    g.endFill();
    container.addChild(g);

    // Label
    this._addLabel(container, sym.name.toUpperCase(), '#ffd700', s);
  }

  /** Premium symbols — diamond emblem */
  _drawPremium(container, sym, s) {
    const col = PIXI.utils.string2hex(sym.baseColor);
    const accent = PIXI.utils.string2hex(sym.accentColor);
    const g = new PIXI.Graphics();
    // Background
    g.beginFill(0x0e0c08);
    g.drawRoundedRect(4, 4, s, s, 10);
    g.endFill();
    g.lineStyle(2, col, 0.6);
    g.drawRoundedRect(8, 8, s - 8, s - 8, 8);
    // Diamond shape
    g.lineStyle(0);
    g.beginFill(col, 0.85);
    g.moveTo(s / 2 + 4, 22);
    g.lineTo(s - 18, s / 2 + 4);
    g.lineTo(s / 2 + 4, s - 14);
    g.lineTo(22, s / 2 + 4);
    g.closePath();
    g.endFill();
    // Inner diamond
    g.beginFill(accent, 0.5);
    g.moveTo(s / 2 + 4, 36);
    g.lineTo(s - 32, s / 2 + 4);
    g.lineTo(s / 2 + 4, s - 28);
    g.lineTo(36, s / 2 + 4);
    g.closePath();
    g.endFill();
    // Highlight
    g.beginFill(0xffffff, 0.15);
    g.moveTo(s / 2 + 4, 22);
    g.lineTo(s - 18, s / 2 + 4);
    g.lineTo(s / 2 + 4, 36);
    g.lineTo(22, s / 2 + 4);
    g.closePath();
    g.endFill();
    container.addChild(g);

    this._addLabel(container, sym.name.toUpperCase(), '#a09070', s);
  }

  /** Mid-tier symbols — circle emblem */
  _drawMid(container, sym, s) {
    const col = PIXI.utils.string2hex(sym.baseColor);
    const g = new PIXI.Graphics();
    g.beginFill(0x0e0c08);
    g.drawRoundedRect(4, 4, s, s, 10);
    g.endFill();
    g.lineStyle(2, col, 0.5);
    g.drawRoundedRect(8, 8, s - 8, s - 8, 8);
    // Circle emblem
    g.lineStyle(0);
    g.beginFill(col, 0.75);
    g.drawCircle(s / 2 + 4, s / 2 + 4, 36);
    g.endFill();
    g.beginFill(0x0e0c08, 0.6);
    g.drawCircle(s / 2 + 4, s / 2 + 4, 22);
    g.endFill();
    g.beginFill(col, 0.9);
    g.drawCircle(s / 2 + 4, s / 2 + 4, 10);
    g.endFill();
    container.addChild(g);

    this._addLabel(container, sym.name.toUpperCase(), '#a09070', s);
  }

  /** Low-tier symbols — large card letter */
  _drawLow(container, sym, s) {
    const col = PIXI.utils.string2hex(sym.baseColor);
    const g = new PIXI.Graphics();
    g.beginFill(0x0c0a07);
    g.drawRoundedRect(4, 4, s, s, 8);
    g.endFill();
    g.lineStyle(1.5, col, 0.4);
    g.drawRoundedRect(8, 8, s - 8, s - 8, 6);
    container.addChild(g);

    // Big card letter
    const letter = sym.shortName || sym.name.charAt(0);
    const txt = new PIXI.Text(letter, {
      fontFamily: 'Cinzel, Georgia, serif',
      fontSize: 62,
      fontWeight: '900',
      fill: sym.baseColor,
      align: 'center',
      dropShadow: true,
      dropShadowColor: sym.accentColor,
      dropShadowDistance: 0,
      dropShadowBlur: 12,
    });
    txt.anchor.set(0.5);
    txt.x = s / 2 + 4;
    txt.y = s / 2 + 4;
    container.addChild(txt);
  }

  /** Add a small name label at the bottom of a symbol */
  _addLabel(container, text, color, s) {
    const txt = new PIXI.Text(text, {
      fontFamily: 'Cinzel, Georgia, serif',
      fontSize: 11,
      fontWeight: '700',
      fill: color,
      align: 'center',
      letterSpacing: 1,
    });
    txt.anchor.set(0.5);
    txt.x = s / 2 + 4;
    txt.y = s - 6;
    container.addChild(txt);
  }
}
